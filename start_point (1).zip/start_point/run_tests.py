from tests.python_functions_test import *

if __name__ == '__main__':
    unittest.main()
